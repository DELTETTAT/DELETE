"""
Web interface module for face matching system.

Provides Streamlit web application with multiple pages:
- app: Main application entry point
- pages: Individual application pages
"""
