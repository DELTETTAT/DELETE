"""
Interface modules for face matching system.

Provides both CLI and web interfaces:
- cli: Command-line interface tools
- web: Streamlit web application
"""
